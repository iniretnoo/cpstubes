import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { EmergencyControls } from "@/components/emergency-controls"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Kontrol Darurat - Sistem Akses Pintu RFID",
  description: "Kontrol darurat untuk situasi khusus pada sistem akses pintu berbasis RFID",
}

export default function EmergencyPage() {
  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Kontrol Darurat</h1>
      </div>

      <div className="space-y-6">
        <Card className="overflow-hidden">
          <CardHeader className="card-header-gradient">
            <CardTitle>Kontrol Darurat</CardTitle>
            <CardDescription>
              Halaman ini berisi kontrol darurat untuk situasi khusus. Gunakan dengan hati-hati.
            </CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-6">
              <EmergencyControls />

              <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 dark:border-amber-900 dark:bg-amber-900/20">
                <h3 className="mb-2 text-lg font-semibold text-amber-800 dark:text-amber-400">Petunjuk Penggunaan</h3>
                <ul className="list-inside list-disc space-y-2 text-amber-700 dark:text-amber-300">
                  <li>
                    <strong>Aktifkan Lockdown</strong> - Mengunci semua pintu dan mengaktifkan mode lockdown. Hanya
                    admin yang dapat membuka pintu selama lockdown aktif.
                  </li>
                  <li>
                    <strong>Override Pintu</strong> - Membuka pintu secara paksa, bahkan jika dalam mode lockdown.
                    Gunakan hanya untuk situasi darurat.
                  </li>
                  <li>
                    <strong>Nonaktifkan Lockdown</strong> - Menonaktifkan mode lockdown dan mengembalikan operasi
                    normal.
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
