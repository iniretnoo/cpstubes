import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { v4 as uuidv4 } from "uuid"

// Get motion alerts with optional filtering
export async function GET(request: Request) {
  try {
    // Check if user is authorized
    const currentUser = await getCurrentUser()
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const location = searchParams.get("location")
    const severity = searchParams.get("severity")
    const status = searchParams.get("status")
    const startDate = searchParams.get("startDate")
    const endDate = searchParams.get("endDate")
    const limit = searchParams.get("limit") ? Number.parseInt(searchParams.get("limit")!) : undefined

    // Build query
    let queryText = `
      SELECT id, timestamp, location, severity, status
      FROM motion_alerts
      WHERE 1=1
    `

    const queryParams: any[] = []
    let paramIndex = 1

    if (location) {
      queryText += ` AND location ILIKE $${paramIndex}`
      queryParams.push(`%${location}%`)
      paramIndex++
    }

    if (severity) {
      queryText += ` AND severity = $${paramIndex}`
      queryParams.push(severity)
      paramIndex++
    }

    if (status) {
      queryText += ` AND status = $${paramIndex}`
      queryParams.push(status)
      paramIndex++
    }

    if (startDate) {
      queryText += ` AND timestamp >= $${paramIndex}`
      queryParams.push(startDate)
      paramIndex++
    }

    if (endDate) {
      queryText += ` AND timestamp <= $${paramIndex}`
      queryParams.push(endDate)
      paramIndex++
    }

    // Order by timestamp descending
    queryText += " ORDER BY timestamp DESC"

    // Add limit if specified
    if (limit) {
      queryText += ` LIMIT $${paramIndex}`
      queryParams.push(limit)
    }

    const result = await query(queryText, queryParams)

    return NextResponse.json({ data: result.rows })
  } catch (error) {
    console.error("Error fetching motion alerts:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Create a new motion alert (manual entry)
export async function POST(request: Request) {
  try {
    // Check if user is authorized (admin only)
    const currentUser = await getCurrentUser()
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { location, severity, status, timestamp } = body

    if (!location || !severity || !status) {
      return NextResponse.json({ error: "Location, severity, and status are required" }, { status: 400 })
    }

    const id = uuidv4()
    const now = timestamp || new Date().toISOString()

    // Create motion alert
    const result = await query(
      `INSERT INTO motion_alerts (id, location, severity, status, timestamp)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, location, severity, status, timestamp`,
      [id, location, severity, status, now],
    )

    // Create notification
    const notificationId = uuidv4()
    const severityText = severity === "high" ? "tinggi" : severity === "medium" ? "sedang" : "rendah"
    const message = `Alarm gerakan ${severityText} terdeteksi di ${location}`

    await query("INSERT INTO notifications (id, type, message) VALUES ($1, $2, $3)", [
      notificationId,
      "motion",
      message,
    ])

    return NextResponse.json({ success: true, data: result.rows[0] })
  } catch (error) {
    console.error("Error creating motion alert:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Update a motion alert (e.g., resolve it)
export async function PUT(request: Request) {
  try {
    // Check if user is authorized (admin only)
    const currentUser = await getCurrentUser()
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { id, status } = body

    if (!id || !status) {
      return NextResponse.json({ error: "ID and status are required" }, { status: 400 })
    }

    // Update motion alert
    const result = await query(
      `UPDATE motion_alerts SET status = $1, updated_at = NOW()
       WHERE id = $2
       RETURNING id, location, severity, status, timestamp`,
      [status, id],
    )

    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Motion alert not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true, data: result.rows[0] })
  } catch (error) {
    console.error("Error updating motion alert:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
