import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { getCurrentUser } from "@/lib/auth"
import { query } from "@/lib/db"
import { v4 as uuidv4 } from "uuid"

export async function POST() {
  try {
    // Get current user before clearing cookie
    const user = await getCurrentUser()

    // Clear the token cookie
    cookies().set({
      name: "token",
      value: "",
      expires: new Date(0),
      path: "/",
    })

    // Log logout action if user was logged in
    if (user) {
      const logId = uuidv4()
      await query("INSERT INTO system_logs (id, action, user_id) VALUES ($1, $2, $3)", [logId, "logout", user.id])
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Logout error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
