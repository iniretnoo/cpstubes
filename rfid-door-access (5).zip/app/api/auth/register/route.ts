import { NextResponse } from "next/server"
import { createUser } from "@/lib/auth"
import { query } from "@/lib/db"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { username, password, name, role, cardId, department, status } = body

    if (!username || !password || !name) {
      return NextResponse.json({ error: "Username, password, and name are required" }, { status: 400 })
    }

    // Check if username already exists
    const existingUserResult = await query("SELECT * FROM users WHERE username = $1", [username])

    if (existingUserResult.rows.length > 0) {
      return NextResponse.json({ error: "Username already exists" }, { status: 400 })
    }

    // Check if cardId already exists (if provided)
    if (cardId) {
      const existingCardResult = await query("SELECT * FROM users WHERE card_id = $1", [cardId])

      if (existingCardResult.rows.length > 0) {
        return NextResponse.json({ error: "Card ID already exists" }, { status: 400 })
      }
    }

    // Create user
    const user = await createUser({
      username,
      password,
      name,
      role,
      cardId,
      department,
      status,
    })

    return NextResponse.json({ success: true, user })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
