import { NextResponse } from "next/server"
import { getMqttClient } from "@/lib/mqtt"

export async function GET() {
  try {
    const client = getMqttClient()

    return NextResponse.json({
      connected: client?.connected || false,
      lastMessage: global.lastMqttMessage || null,
    })
  } catch (error) {
    console.error("Error getting MQTT status:", error)
    return NextResponse.json({ error: "Terjadi kesalahan saat mengambil status MQTT" }, { status: 500 })
  }
}
