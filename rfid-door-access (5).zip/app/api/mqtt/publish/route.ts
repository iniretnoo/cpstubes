import { NextResponse } from "next/server"
import { publishMqttMessage } from "@/lib/mqtt"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { topic, message } = body

    if (!topic || !message) {
      return NextResponse.json({ error: "Topic dan message diperlukan" }, { status: 400 })
    }

    const published = publishMqttMessage(topic, message)

    if (!published) {
      return NextResponse.json({ error: "MQTT client tidak terhubung" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error publishing MQTT message:", error)
    return NextResponse.json({ error: "Terjadi kesalahan saat mempublikasikan pesan MQTT" }, { status: 500 })
  }
}
