import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const location = searchParams.get("location")
    const status = searchParams.get("status")
    const lockdownActive =
      searchParams.get("lockdownActive") === "true"
        ? true
        : searchParams.get("lockdownActive") === "false"
          ? false
          : undefined
    const overrideActive =
      searchParams.get("overrideActive") === "true"
        ? true
        : searchParams.get("overrideActive") === "false"
          ? false
          : undefined

    const where: any = {}

    if (location) {
      where.location = location
    }

    if (status) {
      where.status = status
    }

    if (lockdownActive !== undefined) {
      where.lockdownActive = lockdownActive
    }

    if (overrideActive !== undefined) {
      where.overrideActive = overrideActive
    }

    const doorStatuses = await prisma.doorStatus.findMany({
      where,
      orderBy: {
        location: "asc",
      },
    })

    return NextResponse.json({ data: doorStatuses })
  } catch (error) {
    console.error("Error fetching door statuses:", error)
    return NextResponse.json({ error: "Terjadi kesalahan saat mengambil status pintu" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { location, status, lockdownActive, overrideActive } = body

    if (!location || !status) {
      return NextResponse.json({ error: "Location dan status diperlukan" }, { status: 400 })
    }

    // Update or create door status
    const doorStatus = await prisma.doorStatus.upsert({
      where: { location },
      update: {
        status,
        ...(status === "open" ? { lastOpenTime: new Date() } : { lastCloseTime: new Date() }),
        ...(lockdownActive !== undefined ? { lockdownActive } : {}),
        ...(overrideActive !== undefined ? { overrideActive } : {}),
      },
      create: {
        location,
        status,
        ...(status === "open" ? { lastOpenTime: new Date() } : { lastCloseTime: new Date() }),
        lockdownActive: lockdownActive || false,
        overrideActive: overrideActive || false,
      },
    })

    return NextResponse.json({ success: true, data: doorStatus })
  } catch (error) {
    console.error("Error updating door status:", error)
    return NextResponse.json({ error: "Terjadi kesalahan saat memperbarui status pintu" }, { status: 500 })
  }
}
