import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { publishMqttMessage } from "@/lib/mqtt"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { doorId, location, userId, reason } = body

    if (!location) {
      return NextResponse.json({ error: "Location pintu diperlukan" }, { status: 400 })
    }

    // Verifikasi bahwa pengguna adalah admin (idealnya dilakukan dengan middleware)
    // Untuk demo, kita akan memeriksa userId yang dikirim
    if (userId) {
      const user = await prisma.user.findUnique({
        where: { id: userId },
      })

      if (!user || user.role !== "admin") {
        return NextResponse.json({ error: "Hanya admin yang dapat melakukan override pintu" }, { status: 403 })
      }
    } else {
      return NextResponse.json({ error: "User ID diperlukan" }, { status: 400 })
    }

    // Log aktivitas override
    await prisma.doorOverrideLog.create({
      data: {
        doorId: doorId || location,
        location,
        userId,
        reason: reason || "Emergency override",
        timestamp: new Date(),
      },
    })

    // Update status pintu di database
    await prisma.doorStatus.upsert({
      where: { location },
      update: {
        status: "open",
        lastOpenTime: new Date(),
        overrideActive: true,
      },
      create: {
        location,
        status: "open",
        lastOpenTime: new Date(),
        overrideActive: true,
      },
    })

    // Kirim perintah override melalui MQTT
    const mqttTopic = `rfid/door/${location}/command`
    const mqttMessage = {
      command: "override_open",
      timestamp: new Date().toISOString(),
      source: "admin_api",
      emergency: true,
    }

    const published = publishMqttMessage(mqttTopic, mqttMessage)

    if (!published) {
      // Jika MQTT gagal, kita masih mengembalikan sukses karena database sudah diupdate
      // tapi kita catat bahwa MQTT gagal
      console.error("Failed to publish MQTT message for door override")
    }

    // Buat notifikasi untuk semua admin
    await prisma.notification.create({
      data: {
        type: "override",
        message: `EMERGENCY: ${location} dibuka secara paksa oleh admin. Alasan: ${reason || "Emergency override"}`,
        timestamp: new Date(),
        read: false,
        priority: "high",
      },
    })

    return NextResponse.json({
      success: true,
      message: "Perintah override berhasil dikirim",
      mqttStatus: published ? "success" : "failed",
    })
  } catch (error) {
    console.error("Error overriding door:", error)
    return NextResponse.json({ error: "Terjadi kesalahan saat override pintu" }, { status: 500 })
  }
}
