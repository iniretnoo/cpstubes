import { NextResponse } from "next/server"
import { prisma } from "@/lib/prisma"
import { publishMqttMessage } from "@/lib/mqtt"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { userId, reason, allDoors = true, locations = [] } = body

    // Verifikasi bahwa pengguna adalah admin
    if (userId) {
      const user = await prisma.user.findUnique({
        where: { id: userId },
      })

      if (!user || user.role !== "admin") {
        return NextResponse.json({ error: "Hanya admin yang dapat melakukan lockdown" }, { status: 403 })
      }
    } else {
      return NextResponse.json({ error: "User ID diperlukan" }, { status: 400 })
    }

    // Jika allDoors true, ambil semua lokasi pintu dari database
    let doorsToLockdown: string[] = []

    if (allDoors) {
      const doors = await prisma.doorStatus.findMany({
        select: { location: true },
      })
      doorsToLockdown = doors.map((door) => door.location)
    } else if (locations && locations.length > 0) {
      doorsToLockdown = locations
    } else {
      return NextResponse.json({ error: "Tidak ada pintu yang ditentukan untuk lockdown" }, { status: 400 })
    }

    // Log aktivitas lockdown
    await prisma.systemLog.create({
      data: {
        action: "lockdown",
        userId,
        details: JSON.stringify({
          reason: reason || "Security lockdown",
          doors: doorsToLockdown,
        }),
        timestamp: new Date(),
      },
    })

    // Update status lockdown di database
    for (const location of doorsToLockdown) {
      await prisma.doorStatus.upsert({
        where: { location },
        update: {
          status: "closed",
          lastCloseTime: new Date(),
          lockdownActive: true,
        },
        create: {
          location,
          status: "closed",
          lastCloseTime: new Date(),
          lockdownActive: true,
        },
      })

      // Kirim perintah lockdown melalui MQTT
      const mqttTopic = `rfid/door/${location}/command`
      const mqttMessage = {
        command: "lockdown",
        timestamp: new Date().toISOString(),
        source: "admin_api",
        emergency: true,
      }

      publishMqttMessage(mqttTopic, mqttMessage)
    }

    // Buat notifikasi untuk semua admin
    await prisma.notification.create({
      data: {
        type: "lockdown",
        message: `EMERGENCY: Lockdown diaktifkan untuk ${doorsToLockdown.length} pintu. Alasan: ${reason || "Security lockdown"}`,
        timestamp: new Date(),
        read: false,
        priority: "high",
      },
    })

    return NextResponse.json({
      success: true,
      message: "Lockdown berhasil diaktifkan",
      affectedDoors: doorsToLockdown,
    })
  } catch (error) {
    console.error("Error activating lockdown:", error)
    return NextResponse.json({ error: "Terjadi kesalahan saat mengaktifkan lockdown" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")
    const location = searchParams.get("location")
    const allDoors = searchParams.get("allDoors") === "true"

    // Verifikasi bahwa pengguna adalah admin
    if (userId) {
      const user = await prisma.user.findUnique({
        where: { id: userId },
      })

      if (!user || user.role !== "admin") {
        return NextResponse.json({ error: "Hanya admin yang dapat menonaktifkan lockdown" }, { status: 403 })
      }
    } else {
      return NextResponse.json({ error: "User ID diperlukan" }, { status: 400 })
    }

    let doorsToUnlock: string[] = []

    if (allDoors) {
      // Ambil semua pintu yang sedang dalam lockdown
      const doors = await prisma.doorStatus.findMany({
        where: { lockdownActive: true },
        select: { location: true },
      })
      doorsToUnlock = doors.map((door) => door.location)
    } else if (location) {
      doorsToUnlock = [location]
    } else {
      return NextResponse.json(
        { error: "Tidak ada pintu yang ditentukan untuk menonaktifkan lockdown" },
        { status: 400 },
      )
    }

    // Log aktivitas menonaktifkan lockdown
    await prisma.systemLog.create({
      data: {
        action: "deactivate_lockdown",
        userId,
        details: JSON.stringify({
          doors: doorsToUnlock,
        }),
        timestamp: new Date(),
      },
    })

    // Update status lockdown di database
    for (const doorLocation of doorsToUnlock) {
      await prisma.doorStatus.update({
        where: { location: doorLocation },
        data: {
          lockdownActive: false,
        },
      })

      // Kirim perintah menonaktifkan lockdown melalui MQTT
      const mqttTopic = `rfid/door/${doorLocation}/command`
      const mqttMessage = {
        command: "deactivate_lockdown",
        timestamp: new Date().toISOString(),
        source: "admin_api",
      }

      publishMqttMessage(mqttTopic, mqttMessage)
    }

    // Buat notifikasi
    await prisma.notification.create({
      data: {
        type: "lockdown_deactivated",
        message: `Lockdown dinonaktifkan untuk ${doorsToUnlock.length} pintu oleh admin.`,
        timestamp: new Date(),
        read: false,
      },
    })

    return NextResponse.json({
      success: true,
      message: "Lockdown berhasil dinonaktifkan",
      affectedDoors: doorsToUnlock,
    })
  } catch (error) {
    console.error("Error deactivating lockdown:", error)
    return NextResponse.json({ error: "Terjadi kesalahan saat menonaktifkan lockdown" }, { status: 500 })
  }
}
