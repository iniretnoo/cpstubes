import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { v4 as uuidv4 } from "uuid"

// Get notifications with optional filtering
export async function GET(request: Request) {
  try {
    // Check if user is authorized
    const currentUser = await getCurrentUser()
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type")
    const userId = searchParams.get("userId")
    const read = searchParams.get("read") === "true" ? true : searchParams.get("read") === "false" ? false : undefined
    const limit = searchParams.get("limit") ? Number.parseInt(searchParams.get("limit")!) : undefined

    // Build query
    let queryText = `
      SELECT id, type, message, timestamp, read, user_id AS "userId", priority
      FROM notifications
      WHERE 1=1
    `

    const queryParams: any[] = []
    let paramIndex = 1

    // Non-admin users can only see their own notifications or global ones
    if (currentUser.role !== "admin") {
      queryText += ` AND (user_id IS NULL OR user_id = $${paramIndex})`
      queryParams.push(currentUser.id)
      paramIndex++
    } else if (userId) {
      // Admin can filter by user ID
      queryText += ` AND (user_id = $${paramIndex} OR user_id IS NULL)`
      queryParams.push(userId)
      paramIndex++
    }

    if (type) {
      queryText += ` AND type = $${paramIndex}`
      queryParams.push(type)
      paramIndex++
    }

    if (read !== undefined) {
      queryText += ` AND read = $${paramIndex}`
      queryParams.push(read)
      paramIndex++
    }

    // Order by timestamp descending
    queryText += " ORDER BY timestamp DESC"

    // Add limit if specified
    if (limit) {
      queryText += ` LIMIT $${paramIndex}`
      queryParams.push(limit)
    }

    const result = await query(queryText, queryParams)

    return NextResponse.json({ data: result.rows })
  } catch (error) {
    console.error("Error fetching notifications:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Create a new notification
export async function POST(request: Request) {
  try {
    // Check if user is authorized (admin only)
    const currentUser = await getCurrentUser()
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { type, message, userId, priority } = body

    if (!type || !message) {
      return NextResponse.json({ error: "Type and message are required" }, { status: 400 })
    }

    const id = uuidv4()

    // Create notification
    const result = await query(
      `INSERT INTO notifications (id, type, message, user_id, priority)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, type, message, timestamp, read, user_id AS "userId", priority`,
      [id, type, message, userId || null, priority || "normal"],
    )

    return NextResponse.json({ success: true, data: result.rows[0] })
  } catch (error) {
    console.error("Error creating notification:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Update notification read status
export async function PUT(request: Request) {
  try {
    // Check if user is authorized
    const currentUser = await getCurrentUser()
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { id, read } = body

    if (!id || read === undefined) {
      return NextResponse.json({ error: "ID and read status are required" }, { status: 400 })
    }

    // Get notification to check ownership
    const notificationResult = await query("SELECT * FROM notifications WHERE id = $1", [id])

    if (notificationResult.rows.length === 0) {
      return NextResponse.json({ error: "Notification not found" }, { status: 404 })
    }

    const notification = notificationResult.rows[0]

    // Non-admin users can only update their own notifications or global ones
    if (currentUser.role !== "admin" && notification.user_id && notification.user_id !== currentUser.id) {
      return NextResponse.json({ error: "You are not authorized to update this notification" }, { status: 403 })
    }

    // Update notification
    const result = await query(
      `UPDATE notifications SET read = $1
       WHERE id = $2
       RETURNING id, type, message, timestamp, read, user_id AS "userId", priority`,
      [read, id],
    )

    return NextResponse.json({ success: true, data: result.rows[0] })
  } catch (error) {
    console.error("Error updating notification:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
