import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { v4 as uuidv4 } from "uuid"

// Get access logs with optional filtering
export async function GET(request: Request) {
  try {
    // Check if user is authorized
    const currentUser = await getCurrentUser()
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId")
    const cardId = searchParams.get("cardId")
    const location = searchParams.get("location")
    const status = searchParams.get("status")
    const startDate = searchParams.get("startDate")
    const endDate = searchParams.get("endDate")
    const limit = searchParams.get("limit") ? Number.parseInt(searchParams.get("limit")!) : undefined

    // Build query
    let queryText = `
      SELECT al.id, al.user_id AS "userId", u.name AS "userName", 
      al.card_id AS "cardId", al.timestamp, al.location, al.status
      FROM access_logs al
      LEFT JOIN users u ON al.user_id = u.id
      WHERE 1=1
    `

    const queryParams: any[] = []
    let paramIndex = 1

    // Non-admin users can only see their own logs
    if (currentUser.role !== "admin") {
      queryText += ` AND al.user_id = $${paramIndex}`
      queryParams.push(currentUser.id)
      paramIndex++
    } else if (userId) {
      // Admin can filter by user ID
      queryText += ` AND al.user_id = $${paramIndex}`
      queryParams.push(userId)
      paramIndex++
    }

    if (cardId) {
      queryText += ` AND al.card_id = $${paramIndex}`
      queryParams.push(cardId)
      paramIndex++
    }

    if (location) {
      queryText += ` AND al.location ILIKE $${paramIndex}`
      queryParams.push(`%${location}%`)
      paramIndex++
    }

    if (status) {
      queryText += ` AND al.status = $${paramIndex}`
      queryParams.push(status)
      paramIndex++
    }

    if (startDate) {
      queryText += ` AND al.timestamp >= $${paramIndex}`
      queryParams.push(startDate)
      paramIndex++
    }

    if (endDate) {
      queryText += ` AND al.timestamp <= $${paramIndex}`
      queryParams.push(endDate)
      paramIndex++
    }

    // Order by timestamp descending
    queryText += " ORDER BY al.timestamp DESC"

    // Add limit if specified
    if (limit) {
      queryText += ` LIMIT $${paramIndex}`
      queryParams.push(limit)
    }

    const result = await query(queryText, queryParams)

    return NextResponse.json({ data: result.rows })
  } catch (error) {
    console.error("Error fetching access logs:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Create a new access log (manual entry)
export async function POST(request: Request) {
  try {
    // Check if user is authorized (admin only)
    const currentUser = await getCurrentUser()
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { userId, cardId, location, status, timestamp } = body

    if (!cardId || !location || !status) {
      return NextResponse.json({ error: "Card ID, location, and status are required" }, { status: 400 })
    }

    const id = uuidv4()
    const now = timestamp || new Date().toISOString()

    // Create access log
    const result = await query(
      `INSERT INTO access_logs (id, user_id, card_id, location, status, timestamp)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, user_id AS "userId", card_id AS "cardId", location, status, timestamp`,
      [id, userId || null, cardId, location, status, now],
    )

    return NextResponse.json({ success: true, data: result.rows[0] })
  } catch (error) {
    console.error("Error creating access log:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
