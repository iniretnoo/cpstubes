import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

// Get statistics
export async function GET(request: Request) {
  try {
    // Check if user is authorized
    const currentUser = await getCurrentUser();
    if (!currentUser) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || 'daily'; // daily, weekly, monthly
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');

    // Set default date range if not provided
    const now = new Date();
    let start = new Date();
    let end = now;

    if (!startDate) {
      if (period === 'daily') {
        // Last 24 hours
        start.setDate(start.getDate() - 1);
      } else if (period === 'weekly') {
        // Last 7 days
        start.setDate(start.getDate() - 7);
      } else if (period === 'monthly') {
        // Last 30 days
        start.setDate(start.getDate() - 30);
      }
    } else {
      start = new Date(startDate);
    }

    if (endDate) {
      end = new Date(endDate);
    }

    // Format dates for PostgreSQL
    const startStr = start.toISOString();
    const endStr = end.toISOString();

    // Build time interval based on period
    let timeInterval;
    let format;
    
    if (period === 'daily') {
      timeInterval = "1 hour";
      format = "'Hour' HH24";
    } else if (period === 'weekly') {
      timeInterval = "1 day";
      format = "'Day' DD";
    } else if (period === 'monthly') {
      timeInterval = "1 week";
      format = "'Week' WW";
    }

    // Get access statistics
    const accessStatsQuery = `
      SELECT 
        to_char(time_bucket, ${format}) as name,
        COUNT(*) as total,
        SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as success,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
      FROM (
        SELECT 
          date_trunc('${period === 'daily' ? 'hour' : period === 'weekly' ? 'day' : 'week'}', timestamp) as time_bucket,
          status
        FROM access_logs
        WHERE timestamp BETWEEN $1 AND $2
        ${currentUser.role !== 'admin' ? 'AND user_id = $3' : ''}
      ) as subquery
      GROUP BY time_bucket
      ORDER BY time_bucket ASC
    `;

    const accessStatsParams = currentUser.role !== 'admin' 
      ? [startStr, endStr, currentUser.id]
      : [startStr, endStr];

    const accessStatsResult = await query(accessStatsQuery, accessStatsParams);

    // Get motion alert statistics
    const motionStatsQuery = `
      SELECT 
        to_char(time_bucket, ${format}) as name,
        COUNT(*) as total,
        SUM(CASE WHEN severity = 'high' THEN 1 ELSE 0 END) as high,
        SUM(CASE WHEN severity = 'medium' THEN 1 ELSE 0 END
