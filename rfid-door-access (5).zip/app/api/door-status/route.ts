import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"
import { v4 as uuidv4 } from "uuid"

// Get door status with optional filtering
export async function GET(request: Request) {
  try {
    // Check if user is authorized
    const currentUser = await getCurrentUser()
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const location = searchParams.get("location")

    // Build query
    let queryText = `
      SELECT id, location, status, last_open_time AS "lastOpenTime", 
      last_close_time AS "lastCloseTime", lockdown_active AS "lockdownActive", 
      override_active AS "overrideActive", updated_at AS "updatedAt"
      FROM door_status
      WHERE 1=1
    `

    const queryParams: any[] = []
    let paramIndex = 1

    if (location) {
      queryText += ` AND location = $${paramIndex}`
      queryParams.push(location)
      paramIndex++
    }

    const result = await query(queryText, queryParams)

    return NextResponse.json({ data: result.rows })
  } catch (error) {
    console.error("Error fetching door status:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Update door status
export async function PUT(request: Request) {
  try {
    // Check if user is authorized (admin only)
    const currentUser = await getCurrentUser()
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { id, location, status, lockdownActive, overrideActive } = body

    if (!id && !location) {
      return NextResponse.json({ error: "Either ID or location is required" }, { status: 400 })
    }

    if (!status && lockdownActive === undefined && overrideActive === undefined) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    // Check if door exists
    let doorResult
    if (id) {
      doorResult = await query("SELECT * FROM door_status WHERE id = $1", [id])
    } else {
      doorResult = await query("SELECT * FROM door_status WHERE location = $1", [location])
    }

    const now = new Date()

    if (doorResult.rows.length === 0) {
      // Create new door status if it doesn't exist
      const newId = uuidv4()

      const result = await query(
        `INSERT INTO door_status (
          id, location, status, 
          last_open_time, last_close_time,
          lockdown_active, override_active
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING id, location, status, last_open_time AS "lastOpenTime", 
        last_close_time AS "lastCloseTime", lockdown_active AS "lockdownActive", 
        override_active AS "overrideActive", updated_at AS "updatedAt"`,
        [
          newId,
          location,
          status || "closed",
          status === "open" ? now : null,
          status === "closed" ? now : null,
          lockdownActive !== undefined ? lockdownActive : false,
          overrideActive !== undefined ? overrideActive : false,
        ],
      )

      return NextResponse.json({ success: true, data: result.rows[0] })
    } else {
      // Update existing door status
      const door = doorResult.rows[0]
      const updateFields = []
      const updateValues = []
      let paramIndex = 1

      if (status) {
        updateFields.push(`status = $${paramIndex}`)
        updateValues.push(status)
        paramIndex++

        if (status === "open") {
          updateFields.push(`last_open_time = $${paramIndex}`)
          updateValues.push(now)
          paramIndex++
        } else if (status === "closed") {
          updateFields.push(`last_close_time = $${paramIndex}`)
          updateValues.push(now)
          paramIndex++
        }
      }

      if (lockdownActive !== undefined) {
        updateFields.push(`lockdown_active = $${paramIndex}`)
        updateValues.push(lockdownActive)
        paramIndex++
      }

      if (overrideActive !== undefined) {
        updateFields.push(`override_active = $${paramIndex}`)
        updateValues.push(overrideActive)
        paramIndex++
      }

      updateFields.push(`updated_at = NOW()`)

      // Add door ID or location to values array
      if (id) {
        updateValues.push(id)
      } else {
        updateValues.push(location)
      }

      // Update door status
      const result = await query(
        `UPDATE door_status SET ${updateFields.join(", ")} 
         WHERE ${id ? "id" : "location"} = $${paramIndex}
         RETURNING id, location, status, last_open_time AS "lastOpenTime", 
         last_close_time AS "lastCloseTime", lockdown_active AS "lockdownActive", 
         override_active AS "overrideActive", updated_at AS "updatedAt"`,
        updateValues,
      )

      return NextResponse.json({ success: true, data: result.rows[0] })
    }
  } catch (error) {
    console.error("Error updating door status:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
