import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { hashPassword, getCurrentUser } from "@/lib/auth"

// Get a specific user
export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    // Check if user is authorized (admin or self)
    const currentUser = await getCurrentUser()
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Only allow admins or the user themselves to access user data
    if (currentUser.role !== "admin" && currentUser.id !== params.id) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const result = await query(
      `SELECT id, username, name, role, card_id AS "cardId", 
       department, status, created_at AS "createdAt", updated_at AS "updatedAt"
       FROM users WHERE id = $1`,
      [params.id],
    )

    if (result.rows.length === 0) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    return NextResponse.json({ data: result.rows[0] })
  } catch (error) {
    console.error("Error fetching user:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Update a specific user
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    // Check if user is authorized (admin or self)
    const currentUser = await getCurrentUser()
    if (!currentUser) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Only allow admins or the user themselves to update user data
    const isSelf = currentUser.id === params.id
    if (currentUser.role !== "admin" && !isSelf) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const body = await request.json()
    const { username, password, name, role, cardId, department, status } = body

    // Check if user exists
    const userResult = await query("SELECT * FROM users WHERE id = $1", [params.id])

    if (userResult.rows.length === 0) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Non-admin users can only update their own name, password, and department
    if (currentUser.role !== "admin" && isSelf) {
      if (role || status) {
        return NextResponse.json({ error: "You are not authorized to update role or status" }, { status: 403 })
      }
    }

    const updateFields = []
    const updateValues = []
    let paramIndex = 1

    // Check if username is being updated
    if (username && username !== userResult.rows[0].username) {
      // Only admins can change username
      if (currentUser.role !== "admin") {
        return NextResponse.json({ error: "You are not authorized to change username" }, { status: 403 })
      }

      // Check if new username already exists
      const existingUserResult = await query("SELECT * FROM users WHERE username = $1 AND id != $2", [
        username,
        params.id,
      ])

      if (existingUserResult.rows.length > 0) {
        return NextResponse.json({ error: "Username already exists" }, { status: 400 })
      }

      updateFields.push(`username = $${paramIndex}`)
      updateValues.push(username)
      paramIndex++
    }

    // Update password if provided
    if (password) {
      const hashedPassword = await hashPassword(password)
      updateFields.push(`password = $${paramIndex}`)
      updateValues.push(hashedPassword)
      paramIndex++
    }

    // Update other fields if provided
    if (name) {
      updateFields.push(`name = $${paramIndex}`)
      updateValues.push(name)
      paramIndex++
    }

    if (role && currentUser.role === "admin") {
      updateFields.push(`role = $${paramIndex}`)
      updateValues.push(role)
      paramIndex++
    }

    if (cardId !== undefined && currentUser.role === "admin") {
      // Check if card ID already exists
      if (cardId) {
        const existingCardResult = await query("SELECT * FROM users WHERE card_id = $1 AND id != $2", [
          cardId,
          params.id,
        ])

        if (existingCardResult.rows.length > 0) {
          return NextResponse.json({ error: "Card ID already exists" }, { status: 400 })
        }
      }

      updateFields.push(`card_id = $${paramIndex}`)
      updateValues.push(cardId || null)
      paramIndex++
    }

    if (department !== undefined) {
      updateFields.push(`department = $${paramIndex}`)
      updateValues.push(department || null)
      paramIndex++
    }

    if (status && currentUser.role === "admin") {
      updateFields.push(`status = $${paramIndex}`)
      updateValues.push(status)
      paramIndex++
    }

    // Add updated_at timestamp
    updateFields.push(`updated_at = NOW()`)

    if (updateFields.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    // Add user ID to values array
    updateValues.push(params.id)

    // Update user
    const result = await query(
      `UPDATE users SET ${updateFields.join(", ")} 
       WHERE id = $${paramIndex}
       RETURNING id, username, name, role, card_id AS "cardId", department, status, created_at AS "createdAt", updated_at AS "updatedAt"`,
      updateValues,
    )

    return NextResponse.json({ success: true, data: result.rows[0] })
  } catch (error) {
    console.error("Error updating user:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Delete a specific user
export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    // Check if user is authorized (admin only)
    const currentUser = await getCurrentUser()
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Check if user exists
    const userResult = await query("SELECT * FROM users WHERE id = $1", [params.id])

    if (userResult.rows.length === 0) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Prevent deleting yourself
    if (currentUser.id === params.id) {
      return NextResponse.json({ error: "You cannot delete your own account" }, { status: 400 })
    }

    // Delete user
    await query("DELETE FROM users WHERE id = $1", [params.id])

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error deleting user:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
