import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { hashPassword, getCurrentUser } from "@/lib/auth"
import { v4 as uuidv4 } from "uuid"

// Get all users with optional filtering
export async function GET(request: Request) {
  try {
    // Check if user is authorized (admin only)
    const currentUser = await getCurrentUser()
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const role = searchParams.get("role")
    const status = searchParams.get("status")

    let queryText = `
      SELECT id, username, name, role, card_id AS "cardId", 
      department, status, created_at AS "createdAt", updated_at AS "updatedAt"
      FROM users
      WHERE 1=1
    `

    const queryParams: any[] = []
    let paramIndex = 1

    if (role) {
      queryText += ` AND role = $${paramIndex}`
      queryParams.push(role)
      paramIndex++
    }

    if (status) {
      queryText += ` AND status = $${paramIndex}`
      queryParams.push(status)
      paramIndex++
    }

    queryText += " ORDER BY name ASC"

    const result = await query(queryText, queryParams)

    return NextResponse.json({ data: result.rows })
  } catch (error) {
    console.error("Error fetching users:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Create a new user
export async function POST(request: Request) {
  try {
    // Check if user is authorized (admin only)
    const currentUser = await getCurrentUser()
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { username, password, name, role, cardId, department, status } = body

    if (!username || !password || !name) {
      return NextResponse.json({ error: "Username, password, and name are required" }, { status: 400 })
    }

    // Check if username already exists
    const existingUserResult = await query("SELECT * FROM users WHERE username = $1", [username])

    if (existingUserResult.rows.length > 0) {
      return NextResponse.json({ error: "Username already exists" }, { status: 400 })
    }

    // Check if cardId already exists (if provided)
    if (cardId) {
      const existingCardResult = await query("SELECT * FROM users WHERE card_id = $1", [cardId])

      if (existingCardResult.rows.length > 0) {
        return NextResponse.json({ error: "Card ID already exists" }, { status: 400 })
      }
    }

    // Hash password
    const hashedPassword = await hashPassword(password)
    const userId = uuidv4()

    // Create user
    const result = await query(
      `INSERT INTO users (
        id, username, password, name, role, card_id, department, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING id, username, name, role, card_id AS "cardId", department, status, created_at AS "createdAt", updated_at AS "updatedAt"`,
      [userId, username, hashedPassword, name, role || "user", cardId || null, department || null, status || "active"],
    )

    return NextResponse.json({ success: true, data: result.rows[0] })
  } catch (error) {
    console.error("Error creating user:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Update multiple users
export async function PUT(request: Request) {
  try {
    // Check if user is authorized (admin only)
    const currentUser = await getCurrentUser()
    if (!currentUser || currentUser.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    const body = await request.json()
    const { users } = body

    if (!Array.isArray(users) || users.length === 0) {
      return NextResponse.json({ error: "No users provided for update" }, { status: 400 })
    }

    const updatedUsers = []

    for (const user of users) {
      const { id, name, role, cardId, department, status } = user

      if (!id) {
        continue
      }

      const updateFields = []
      const updateValues = []
      let paramIndex = 1

      if (name) {
        updateFields.push(`name = $${paramIndex}`)
        updateValues.push(name)
        paramIndex++
      }

      if (role) {
        updateFields.push(`role = $${paramIndex}`)
        updateValues.push(role)
        paramIndex++
      }

      if (cardId !== undefined) {
        updateFields.push(`card_id = $${paramIndex}`)
        updateValues.push(cardId || null)
        paramIndex++
      }

      if (department !== undefined) {
        updateFields.push(`department = $${paramIndex}`)
        updateValues.push(department || null)
        paramIndex++
      }

      if (status) {
        updateFields.push(`status = $${paramIndex}`)
        updateValues.push(status)
        paramIndex++
      }

      updateFields.push(`updated_at = NOW()`)

      if (updateFields.length > 0) {
        updateValues.push(id)

        const result = await query(
          `UPDATE users SET ${updateFields.join(", ")} 
           WHERE id = $${paramIndex}
           RETURNING id, username, name, role, card_id AS "cardId", department, status, created_at AS "createdAt", updated_at AS "updatedAt"`,
          updateValues,
        )

        if (result.rows.length > 0) {
          updatedUsers.push(result.rows[0])
        }
      }
    }

    return NextResponse.json({ success: true, data: updatedUsers })
  } catch (error) {
    console.error("Error updating users:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
