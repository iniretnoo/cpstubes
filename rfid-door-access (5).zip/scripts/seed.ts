import { PrismaClient } from "@prisma/client"
import { hash } from "bcryptjs"

const prisma = new PrismaClient()

async function main() {
  console.log("Seeding database...")

  // Create admin user
  const adminPassword = await hash("password", 10)
  await prisma.user.upsert({
    where: { username: "admin" },
    update: {},
    create: {
      username: "admin",
      password: adminPassword,
      name: "Administrator",
      role: "admin",
      cardId: "RFID-ADMIN",
      department: "IT",
      status: "active",
    },
  })

  // Create regular user
  const userPassword = await hash("password", 10)
  await prisma.user.upsert({
    where: { username: "user" },
    update: {},
    create: {
      username: "user",
      password: userPassword,
      name: "Ahmad Fauzi",
      role: "user",
      cardId: "RFID-001",
      department: "Finance",
      status: "active",
    },
  })

  // Create door statuses
  await prisma.doorStatus.upsert({
    where: { location: "Pintu Utama" },
    update: {},
    create: {
      location: "Pintu Utama",
      status: "closed",
      lastCloseTime: new Date(),
    },
  })

  await prisma.doorStatus.upsert({
    where: { location: "Pintu Belakang" },
    update: {},
    create: {
      location: "Pintu Belakang",
      status: "closed",
      lastCloseTime: new Date(),
    },
  })

  await prisma.doorStatus.upsert({
    where: { location: "Pintu Samping" },
    update: {},
    create: {
      location: "Pintu Samping",
      status: "closed",
      lastCloseTime: new Date(),
    },
  })

  // Create some access logs
  const now = new Date()

  // Today's logs
  await prisma.accessLog.createMany({
    data: [
      {
        userId: "1", // Will be replaced with actual ID
        cardId: "RFID-001",
        location: "Pintu Utama",
        status: "success",
        timestamp: new Date(now.setHours(8, 30, 0, 0)),
      },
      {
        userId: "1",
        cardId: "RFID-001",
        location: "Pintu Utama",
        status: "success",
        timestamp: new Date(now.setHours(12, 30, 0, 0)),
      },
      {
        userId: "1",
        cardId: "RFID-001",
        location: "Pintu Utama",
        status: "success",
        timestamp: new Date(now.setHours(17, 30, 0, 0)),
      },
      {
        cardId: "RFID-UNKNOWN",
        location: "Pintu Belakang",
        status: "failed",
        timestamp: new Date(now.setHours(14, 15, 0, 0)),
      },
    ],
  })

  // Create some motion alerts
  await prisma.motionAlert.createMany({
    data: [
      {
        location: "Pintu Utama",
        severity: "high",
        status: "resolved",
        timestamp: new Date(now.setHours(2, 15, 0, 0)),
      },
      {
        location: "Pintu Belakang",
        severity: "medium",
        status: "triggered",
        timestamp: new Date(now.setHours(3, 30, 0, 0)),
      },
      {
        location: "Pintu Samping",
        severity: "low",
        status: "resolved",
        timestamp: new Date(now.setHours(14, 20, 0, 0)),
      },
    ],
  })

  // Create some notifications
  await prisma.notification.createMany({
    data: [
      {
        type: "access",
        message: "Ahmad Fauzi mengakses Pintu Utama",
        timestamp: new Date(now.setHours(8, 30, 0, 0)),
        read: false,
      },
      {
        type: "motion",
        message: "Alarm gerakan terdeteksi di Pintu Utama",
        timestamp: new Date(now.setHours(2, 15, 0, 0)),
        read: true,
      },
      {
        type: "door",
        message: "Pintu Utama terbuka lebih dari 5 menit",
        timestamp: new Date(now.setHours(10, 20, 0, 0)),
        read: false,
      },
    ],
  })

  // Create default settings
  await prisma.setting.createMany({
    data: [
      {
        key: "door_open_timeout",
        value: "300", // 5 minutes in seconds
      },
      {
        key: "motion_detection_delay",
        value: "30", // 30 seconds
      },
      {
        key: "email_notifications",
        value: "true",
      },
      {
        key: "dashboard_notifications",
        value: "true",
      },
    ],
  })

  console.log("Database seeded successfully!")
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
