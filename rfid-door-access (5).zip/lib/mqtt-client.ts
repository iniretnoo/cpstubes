import mqtt from "mqtt"
import { v4 as uuidv4 } from "uuid"
import { query } from "./db"

let client: mqtt.MqttClient | null = null

export function getMqttClient() {
  if (!client) {
    const mqttUrl = process.env.MQTT_URL || "mqtt://localhost:1883"
    const mqttUsername = process.env.MQTT_USERNAME
    const mqttPassword = process.env.MQTT_PASSWORD

    const options: mqtt.IClientOptions = {
      clientId: `rfid_access_server_${Math.random().toString(16).slice(2, 8)}`,
      clean: true,
      reconnectPeriod: 5000,
    }

    if (mqttUsername && mqttPassword) {
      options.username = mqttUsername
      options.password = mqttPassword
    }

    client = mqtt.connect(mqttUrl, options)

    client.on("connect", () => {
      console.log("Connected to MQTT broker")

      // Subscribe to relevant topics
      client.subscribe("rfid/access", { qos: 1 })
      client.subscribe("rfid/motion", { qos: 1 })
      client.subscribe("rfid/door/+/status", { qos: 1 })

      console.log("Subscribed to RFID topics")
    })

    client.on("message", async (topic, message) => {
      console.log(`Received message on ${topic}: ${message.toString()}`)

      try {
        const payload = JSON.parse(message.toString())

        if (topic === "rfid/access") {
          await handleRfidAccess(payload)
        } else if (topic === "rfid/motion") {
          await handleMotionAlert(payload)
        } else if (topic.startsWith("rfid/door/") && topic.endsWith("/status")) {
          await handleDoorStatus(topic, payload)
        }
      } catch (error) {
        console.error("Error processing MQTT message:", error)
      }
    })

    client.on("error", (err) => {
      console.error("MQTT client error:", err)
    })
  }

  return client
}

async function handleRfidAccess(payload: any) {
  const { cardId, location, status } = payload
  const id = uuidv4()

  try {
    // Find user by card ID
    const userResult = await query("SELECT * FROM users WHERE card_id = $1", [cardId])

    const user = userResult.rows[0]

    // Create access log
    await query("INSERT INTO access_logs (id, user_id, card_id, location, status) VALUES ($1, $2, $3, $4, $5)", [
      id,
      user?.id,
      cardId,
      location,
      status,
    ])

    // Create notification
    const notificationId = uuidv4()
    const message = user
      ? `${user.name} ${status === "success" ? "mengakses" : "gagal mengakses"} ${location}`
      : `Kartu tidak dikenal (${cardId}) mencoba mengakses ${location}`

    await query("INSERT INTO notifications (id, type, message, user_id) VALUES ($1, $2, $3, $4)", [
      notificationId,
      "access",
      message,
      user?.id,
    ])
  } catch (error) {
    console.error("Error handling RFID access:", error)
  }
}

async function handleMotionAlert(payload: any) {
  const { location, severity, status } = payload
  const id = uuidv4()

  try {
    // Create motion alert
    await query("INSERT INTO motion_alerts (id, location, severity, status) VALUES ($1, $2, $3, $4)", [
      id,
      location,
      severity,
      status,
    ])

    // Create notification
    const notificationId = uuidv4()
    const severityText = severity === "high" ? "tinggi" : severity === "medium" ? "sedang" : "rendah"
    const message = `Alarm gerakan ${severityText} terdeteksi di ${location}`

    await query("INSERT INTO notifications (id, type, message) VALUES ($1, $2, $3)", [
      notificationId,
      "motion",
      message,
    ])
  } catch (error) {
    console.error("Error handling motion alert:", error)
  }
}

async function handleDoorStatus(topic: string, payload: any) {
  const { status } = payload
  const locationMatch = topic.match(/rfid\/door\/(.+)\/status/)
  const location = locationMatch ? locationMatch[1] : "unknown"
  const id = uuidv4()

  try {
    // Check if door exists
    const doorResult = await query("SELECT * FROM door_status WHERE location = $1", [location])

    const now = new Date()

    if (doorResult.rows.length === 0) {
      // Create new door status
      await query(
        `INSERT INTO door_status (
          id, location, status, 
          last_open_time, last_close_time
        ) VALUES ($1, $2, $3, $4, $5)`,
        [id, location, status, status === "open" ? now : null, status === "closed" ? now : null],
      )
    } else {
      // Update existing door status
      await query(
        `UPDATE door_status SET 
          status = $1, 
          last_open_time = CASE WHEN $2 = 'open' THEN NOW() ELSE last_open_time END,
          last_close_time = CASE WHEN $2 = 'closed' THEN NOW() ELSE last_close_time END,
          updated_at = NOW()
        WHERE location = $3`,
        [status, status, location],
      )
    }

    // Create notification if door is open for too long (more than 5 minutes)
    if (status === "open") {
      const doorStatus = doorResult.rows[0]

      if (doorStatus && doorStatus.last_open_time) {
        const lastOpenTime = new Date(doorStatus.last_open_time)
        const openDuration = (now.getTime() - lastOpenTime.getTime()) / (1000 * 60) // in minutes

        if (openDuration > 5) {
          const notificationId = uuidv4()
          await query("INSERT INTO notifications (id, type, message) VALUES ($1, $2, $3)", [
            notificationId,
            "door",
            `${location} terbuka lebih dari 5 menit`,
          ])
        }
      }
    }
  } catch (error) {
    console.error("Error handling door status:", error)
  }
}

export function publishMqttMessage(topic: string, message: any) {
  const client = getMqttClient()
  if (client && client.connected) {
    client.publish(topic, JSON.stringify(message), { qos: 1 })
    return true
  }
  return false
}
