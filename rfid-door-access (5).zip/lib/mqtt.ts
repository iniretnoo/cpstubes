import mqtt from "mqtt"
import { prisma } from "./prisma"

let client: mqtt.MqttClient | null = null

export function getMqttClient() {
  if (!client) {
    const mqttUrl = process.env.MQTT_URL || "mqtt://localhost:1883"
    const mqttUsername = process.env.MQTT_USERNAME
    const mqttPassword = process.env.MQTT_PASSWORD

    const options: mqtt.IClientOptions = {
      clientId: `rfid_access_server_${Math.random().toString(16).slice(2, 8)}`,
      clean: true,
      reconnectPeriod: 5000,
    }

    if (mqttUsername && mqttPassword) {
      options.username = mqttUsername
      options.password = mqttPassword
    }

    client = mqtt.connect(mqttUrl, options)

    client.on("connect", () => {
      console.log("Connected to MQTT broker")

      // Subscribe to relevant topics
      client.subscribe("rfid/access", { qos: 1 })
      client.subscribe("rfid/motion", { qos: 1 })
      client.subscribe("rfid/door/+/status", { qos: 1 })

      console.log("Subscribed to RFID topics")
    })

    client.on("message", async (topic, message) => {
      console.log(`Received message on ${topic}: ${message.toString()}`)

      try {
        const payload = JSON.parse(message.toString())

        if (topic === "rfid/access") {
          await handleRfidAccess(payload)
        } else if (topic === "rfid/motion") {
          await handleMotionAlert(payload)
        } else if (topic.startsWith("rfid/door/") && topic.endsWith("/status")) {
          await handleDoorStatus(topic, payload)
        }
      } catch (error) {
        console.error("Error processing MQTT message:", error)
      }
    })

    client.on("error", (err) => {
      console.error("MQTT client error:", err)
    })
  }

  return client
}

async function handleRfidAccess(payload: any) {
  const { cardId, location, status } = payload

  try {
    // Find user by card ID
    const user = await prisma.user.findUnique({
      where: { cardId },
    })

    // Create access log
    await prisma.accessLog.create({
      data: {
        userId: user?.id,
        cardId,
        location,
        status,
      },
    })

    // Create notification
    await prisma.notification.create({
      data: {
        type: "access",
        message: user
          ? `${user.name} ${status === "success" ? "mengakses" : "gagal mengakses"} ${location}`
          : `Kartu tidak dikenal (${cardId}) mencoba mengakses ${location}`,
        userId: user?.id,
      },
    })
  } catch (error) {
    console.error("Error handling RFID access:", error)
  }
}

async function handleMotionAlert(payload: any) {
  const { location, severity, status } = payload

  try {
    // Create motion alert
    await prisma.motionAlert.create({
      data: {
        location,
        severity,
        status,
      },
    })

    // Create notification
    await prisma.notification.create({
      data: {
        type: "motion",
        message: `Alarm gerakan ${severity === "high" ? "tinggi" : severity === "medium" ? "sedang" : "rendah"} terdeteksi di ${location}`,
      },
    })
  } catch (error) {
    console.error("Error handling motion alert:", error)
  }
}

async function handleDoorStatus(topic: string, payload: any) {
  const { status } = payload
  const locationMatch = topic.match(/rfid\/door\/(.+)\/status/)
  const location = locationMatch ? locationMatch[1] : "unknown"

  try {
    // Update door status
    await prisma.doorStatus.upsert({
      where: { location },
      update: {
        status,
        ...(status === "open" ? { lastOpenTime: new Date() } : { lastCloseTime: new Date() }),
      },
      create: {
        location,
        status,
        ...(status === "open" ? { lastOpenTime: new Date() } : { lastCloseTime: new Date() }),
      },
    })

    // Create notification if door is open for too long (more than 5 minutes)
    if (status === "open") {
      const doorStatus = await prisma.doorStatus.findUnique({
        where: { location },
      })

      if (doorStatus && doorStatus.lastOpenTime) {
        const openDuration = new Date().getTime() - doorStatus.lastOpenTime.getTime()
        const openMinutes = openDuration / (1000 * 60)

        if (openMinutes > 5) {
          await prisma.notification.create({
            data: {
              type: "door",
              message: `${location} terbuka lebih dari 5 menit`,
            },
          })
        }
      }
    }
  } catch (error) {
    console.error("Error handling door status:", error)
  }
}

export function publishMqttMessage(topic: string, message: any) {
  const client = getMqttClient()
  if (client && client.connected) {
    client.publish(topic, JSON.stringify(message), { qos: 1 })
    return true
  }
  return false
}
