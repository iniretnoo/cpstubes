import { Pool } from "pg"

// Create a PostgreSQL connection pool
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
})

// Helper function to execute SQL queries
export async function query(text: string, params?: any[]) {
  const start = Date.now()
  try {
    const res = await pool.query(text, params)
    const duration = Date.now() - start
    console.log("Executed query", { text, duration, rows: res.rowCount })
    return res
  } catch (error) {
    console.error("Error executing query", { text, error })
    throw error
  }
}

// Initialize database tables
export async function initDatabase() {
  try {
    // Create users table
    await query(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(50) PRIMARY KEY,
        username VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(100) NOT NULL,
        name VARCHAR(100) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'user',
        card_id VARCHAR(50) UNIQUE,
        department VARCHAR(100),
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `)

    // Create access_logs table
    await query(`
      CREATE TABLE IF NOT EXISTS access_logs (
        id VARCHAR(50) PRIMARY KEY,
        user_id VARCHAR(50),
        card_id VARCHAR(50) NOT NULL,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
        location VARCHAR(100) NOT NULL,
        status VARCHAR(20) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      )
    `)

    // Create motion_alerts table
    await query(`
      CREATE TABLE IF NOT EXISTS motion_alerts (
        id VARCHAR(50) PRIMARY KEY,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
        location VARCHAR(100) NOT NULL,
        severity VARCHAR(20) NOT NULL,
        status VARCHAR(20) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `)

    // Create door_status table
    await query(`
      CREATE TABLE IF NOT EXISTS door_status (
        id VARCHAR(50) PRIMARY KEY,
        location VARCHAR(100) UNIQUE NOT NULL,
        status VARCHAR(20) NOT NULL,
        last_open_time TIMESTAMP,
        last_close_time TIMESTAMP,
        lockdown_active BOOLEAN NOT NULL DEFAULT FALSE,
        override_active BOOLEAN NOT NULL DEFAULT FALSE,
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `)

    // Create notifications table
    await query(`
      CREATE TABLE IF NOT EXISTS notifications (
        id VARCHAR(50) PRIMARY KEY,
        type VARCHAR(50) NOT NULL,
        message TEXT NOT NULL,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
        read BOOLEAN NOT NULL DEFAULT FALSE,
        user_id VARCHAR(50),
        priority VARCHAR(20) NOT NULL DEFAULT 'normal',
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      )
    `)

    // Create system_logs table
    await query(`
      CREATE TABLE IF NOT EXISTS system_logs (
        id VARCHAR(50) PRIMARY KEY,
        action VARCHAR(50) NOT NULL,
        user_id VARCHAR(50),
        details TEXT,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
      )
    `)

    // Create door_override_logs table
    await query(`
      CREATE TABLE IF NOT EXISTS door_override_logs (
        id VARCHAR(50) PRIMARY KEY,
        door_id VARCHAR(50) NOT NULL,
        location VARCHAR(100) NOT NULL,
        user_id VARCHAR(50) NOT NULL,
        reason TEXT,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `)

    // Create settings table
    await query(`
      CREATE TABLE IF NOT EXISTS settings (
        id VARCHAR(50) PRIMARY KEY,
        key VARCHAR(100) UNIQUE NOT NULL,
        value TEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )
    `)

    console.log("Database tables initialized successfully")
  } catch (error) {
    console.error("Error initializing database tables", error)
    throw error
  }
}
