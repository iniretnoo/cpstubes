import { compare, hash } from "bcryptjs"
import { query } from "./db"
import { v4 as uuidv4 } from "uuid"
import { cookies } from "next/headers"
import { SignJWT, jwtVerify } from "jose"

// Secret key for JWT
const secretKey = new TextEncoder().encode(process.env.JWT_SECRET || "default_secret_key_change_this_in_production")

// Hash password
export async function hashPassword(password: string): Promise<string> {
  return await hash(password, 10)
}

// Validate credentials
export async function validateCredentials(username: string, password: string) {
  try {
    const result = await query("SELECT * FROM users WHERE username = $1", [username])

    const user = result.rows[0]
    if (!user) {
      return null
    }

    const isValid = await compare(password, user.password)
    if (!isValid) {
      return null
    }

    // Don't return the password
    const { password: _, ...userWithoutPassword } = user
    return userWithoutPassword
  } catch (error) {
    console.error("Error validating credentials:", error)
    return null
  }
}

// Create JWT token
export async function createToken(payload: any) {
  return await new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(secretKey)
}

// Verify JWT token
export async function verifyToken(token: string) {
  try {
    const { payload } = await jwtVerify(token, secretKey)
    return payload
  } catch (error) {
    return null
  }
}

// Get current user from token
export async function getCurrentUser() {
  const cookieStore = cookies()
  const token = cookieStore.get("token")?.value

  if (!token) {
    return null
  }

  try {
    const payload = await verifyToken(token)
    if (!payload || !payload.id) {
      return null
    }

    const result = await query(
      "SELECT id, username, name, role, card_id, department, status FROM users WHERE id = $1",
      [payload.id],
    )

    return result.rows[0] || null
  } catch (error) {
    console.error("Error getting current user:", error)
    return null
  }
}

// Create a new user
export async function createUser(userData: {
  username: string
  password: string
  name: string
  role?: string
  cardId?: string
  department?: string
  status?: string
}) {
  const hashedPassword = await hashPassword(userData.password)
  const userId = uuidv4()

  try {
    const result = await query(
      `INSERT INTO users (
        id, username, password, name, role, card_id, department, status
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id, username, name, role, card_id, department, status`,
      [
        userId,
        userData.username,
        hashedPassword,
        userData.name,
        userData.role || "user",
        userData.cardId || null,
        userData.department || null,
        userData.status || "active",
      ],
    )

    return result.rows[0]
  } catch (error) {
    console.error("Error creating user:", error)
    throw error
  }
}
