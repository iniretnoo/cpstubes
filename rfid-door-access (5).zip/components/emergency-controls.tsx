"use client"

import { useState } from "react"
import { AlertTriangle, Lock, Unlock, ShieldAlert } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/components/auth-provider"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"

export function EmergencyControls() {
  const { toast } = useToast()
  const { user, isAdmin } = useAuth()
  const [isLockdownDialogOpen, setIsLockdownDialogOpen] = useState(false)
  const [isOverrideDialogOpen, setIsOverrideDialogOpen] = useState(false)
  const [isDeactivateDialogOpen, setIsDeactivateDialogOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [doorLocations, setDoorLocations] = useState<string[]>([])
  const [selectedLocation, setSelectedLocation] = useState<string>("")
  const [reason, setReason] = useState("")
  const [allDoors, setAllDoors] = useState(true)

  // Ambil daftar lokasi pintu saat komponen dimuat
  useState(() => {
    const fetchDoorLocations = async () => {
      try {
        const response = await fetch("/api/door-status")
        const data = await response.json()
        if (data.data) {
          setDoorLocations(data.data.map((door: any) => door.location))
          if (data.data.length > 0) {
            setSelectedLocation(data.data[0].location)
          }
        }
      } catch (error) {
        console.error("Error fetching door locations:", error)
      }
    }

    fetchDoorLocations()
  })

  const handleLockdown = async () => {
    if (!user || !isAdmin) {
      toast({
        title: "Akses Ditolak",
        description: "Hanya admin yang dapat melakukan lockdown",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/door/lockdown", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          reason,
          allDoors,
          locations: allDoors ? [] : [selectedLocation],
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Gagal mengaktifkan lockdown")
      }

      toast({
        title: "Lockdown Diaktifkan",
        description: `Lockdown berhasil diaktifkan untuk ${data.affectedDoors.length} pintu`,
      })

      setIsLockdownDialogOpen(false)
      setReason("")
    } catch (error: any) {
      toast({
        title: "Gagal Mengaktifkan Lockdown",
        description: error.message || "Terjadi kesalahan saat mengaktifkan lockdown",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleOverride = async () => {
    if (!user || !isAdmin) {
      toast({
        title: "Akses Ditolak",
        description: "Hanya admin yang dapat melakukan override",
        variant: "destructive",
      })
      return
    }

    if (!selectedLocation) {
      toast({
        title: "Lokasi Diperlukan",
        description: "Pilih lokasi pintu yang akan di-override",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch("/api/door/override", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId: user.id,
          location: selectedLocation,
          reason,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Gagal melakukan override pintu")
      }

      toast({
        title: "Override Berhasil",
        description: `Pintu ${selectedLocation} berhasil di-override`,
      })

      setIsOverrideDialogOpen(false)
      setReason("")
    } catch (error: any) {
      toast({
        title: "Gagal Melakukan Override",
        description: error.message || "Terjadi kesalahan saat melakukan override pintu",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeactivateLockdown = async () => {
    if (!user || !isAdmin) {
      toast({
        title: "Akses Ditolak",
        description: "Hanya admin yang dapat menonaktifkan lockdown",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      const url = new URL("/api/door/lockdown", window.location.origin)
      url.searchParams.append("userId", user.id)

      if (allDoors) {
        url.searchParams.append("allDoors", "true")
      } else {
        url.searchParams.append("location", selectedLocation)
      }

      const response = await fetch(url.toString(), {
        method: "DELETE",
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Gagal menonaktifkan lockdown")
      }

      toast({
        title: "Lockdown Dinonaktifkan",
        description: `Lockdown berhasil dinonaktifkan untuk ${data.affectedDoors.length} pintu`,
      })

      setIsDeactivateDialogOpen(false)
    } catch (error: any) {
      toast({
        title: "Gagal Menonaktifkan Lockdown",
        description: error.message || "Terjadi kesalahan saat menonaktifkan lockdown",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (!isAdmin) {
    return null
  }

  return (
    <Card className="border-red-200 dark:border-red-800">
      <CardHeader className="bg-red-50 dark:bg-red-900/20">
        <CardTitle className="flex items-center text-red-700 dark:text-red-400">
          <ShieldAlert className="mr-2 h-5 w-5" />
          Kontrol Darurat
        </CardTitle>
        <CardDescription>Kontrol darurat untuk situasi khusus</CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {/* Lockdown Button */}
          <Dialog open={isLockdownDialogOpen} onOpenChange={setIsLockdownDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive" className="w-full">
                <Lock className="mr-2 h-4 w-4" /> Aktifkan Lockdown
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Konfirmasi Lockdown</DialogTitle>
                <DialogDescription>
                  Tindakan ini akan mengunci semua pintu dan mengaktifkan mode lockdown. Hanya admin yang dapat membuka
                  pintu selama lockdown aktif.
                </DialogDescription>
              </DialogHeader>

              <div className="grid gap-4 py-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="all-doors" checked={allDoors} onCheckedChange={(checked) => setAllDoors(!!checked)} />
                  <Label htmlFor="all-doors">Semua Pintu</Label>
                </div>

                {!allDoors && (
                  <div className="grid gap-2">
                    <Label htmlFor="location">Lokasi Pintu</Label>
                    <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                      <SelectTrigger id="location">
                        <SelectValue placeholder="Pilih lokasi pintu" />
                      </SelectTrigger>
                      <SelectContent>
                        {doorLocations.map((location) => (
                          <SelectItem key={location} value={location}>
                            {location}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="grid gap-2">
                  <Label htmlFor="reason">Alasan Lockdown</Label>
                  <Textarea
                    id="reason"
                    placeholder="Masukkan alasan lockdown"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                  />
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsLockdownDialogOpen(false)}>
                  Batal
                </Button>
                <Button variant="destructive" onClick={handleLockdown} disabled={isLoading}>
                  {isLoading ? "Memproses..." : "Aktifkan Lockdown"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Override Button */}
          <Dialog open={isOverrideDialogOpen} onOpenChange={setIsOverrideDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="destructive" className="w-full">
                <AlertTriangle className="mr-2 h-4 w-4" /> Override Pintu
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Override Pintu</DialogTitle>
                <DialogDescription>
                  Tindakan ini akan membuka pintu secara paksa, bahkan jika dalam mode lockdown. Gunakan hanya untuk
                  situasi darurat.
                </DialogDescription>
              </DialogHeader>

              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="override-location">Lokasi Pintu</Label>
                  <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                    <SelectTrigger id="override-location">
                      <SelectValue placeholder="Pilih lokasi pintu" />
                    </SelectTrigger>
                    <SelectContent>
                      {doorLocations.map((location) => (
                        <SelectItem key={location} value={location}>
                          {location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="override-reason">Alasan Override</Label>
                  <Textarea
                    id="override-reason"
                    placeholder="Masukkan alasan override"
                    value={reason}
                    onChange={(e) => setReason(e.target.value)}
                  />
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsOverrideDialogOpen(false)}>
                  Batal
                </Button>
                <Button variant="destructive" onClick={handleOverride} disabled={isLoading}>
                  {isLoading ? "Memproses..." : "Override Pintu"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Deactivate Lockdown Button */}
          <Dialog open={isDeactivateDialogOpen} onOpenChange={setIsDeactivateDialogOpen}>
            <DialogTrigger asChild>
              <Button
                variant="outline"
                className="w-full border-red-200 text-red-700 hover:bg-red-50 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-900/20"
              >
                <Unlock className="mr-2 h-4 w-4" /> Nonaktifkan Lockdown
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Nonaktifkan Lockdown</DialogTitle>
                <DialogDescription>
                  Tindakan ini akan menonaktifkan mode lockdown dan mengembalikan operasi normal.
                </DialogDescription>
              </DialogHeader>

              <div className="grid gap-4 py-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="all-doors-deactivate"
                    checked={allDoors}
                    onCheckedChange={(checked) => setAllDoors(!!checked)}
                  />
                  <Label htmlFor="all-doors-deactivate">Semua Pintu</Label>
                </div>

                {!allDoors && (
                  <div className="grid gap-2">
                    <Label htmlFor="deactivate-location">Lokasi Pintu</Label>
                    <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                      <SelectTrigger id="deactivate-location">
                        <SelectValue placeholder="Pilih lokasi pintu" />
                      </SelectTrigger>
                      <SelectContent>
                        {doorLocations.map((location) => (
                          <SelectItem key={location} value={location}>
                            {location}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDeactivateDialogOpen(false)}>
                  Batal
                </Button>
                <Button variant="default" onClick={handleDeactivateLockdown} disabled={isLoading}>
                  {isLoading ? "Memproses..." : "Nonaktifkan Lockdown"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
      <CardFooter className="bg-red-50 px-6 py-4 text-xs text-red-700 dark:bg-red-900/20 dark:text-red-400">
        <AlertTriangle className="mr-2 h-4 w-4" />
        Perhatian: Kontrol ini hanya untuk situasi darurat. Semua tindakan akan dicatat.
      </CardFooter>
    </Card>
  )
}
