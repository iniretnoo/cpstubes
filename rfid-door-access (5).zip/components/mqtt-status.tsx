"use client"

import { useState, useEffect } from "react"
import { Wifi, WifiOff } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export function MqttStatus() {
  const [isConnected, setIsConnected] = useState(false)
  const [lastMessage, setLastMessage] = useState<string | null>(null)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)

  useEffect(() => {
    // Polling untuk cek status MQTT
    const checkMqttStatus = async () => {
      try {
        const response = await fetch("/api/mqtt/status")
        const data = await response.json()

        setIsConnected(data.connected)
        if (data.lastMessage) {
          setLastMessage(data.lastMessage)
          setLastUpdate(new Date())
        }
      } catch (error) {
        console.error("Error checking MQTT status:", error)
        setIsConnected(false)
      }
    }

    // Cek status saat komponen dimuat
    checkMqttStatus()

    // Polling setiap 10 detik
    const interval = setInterval(checkMqttStatus, 10000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex items-center gap-2">
      {isConnected ? (
        <Badge
          variant="outline"
          className="flex items-center gap-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
        >
          <Wifi className="h-3 w-3" />
          <span>MQTT Connected</span>
        </Badge>
      ) : (
        <Badge
          variant="outline"
          className="flex items-center gap-1 bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
        >
          <WifiOff className="h-3 w-3" />
          <span>MQTT Disconnected</span>
        </Badge>
      )}

      {lastUpdate && (
        <span className="text-xs text-gray-500 dark:text-gray-400">Last update: {lastUpdate.toLocaleTimeString()}</span>
      )}
    </div>
  )
}
