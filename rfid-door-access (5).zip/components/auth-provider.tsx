"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import { useRouter, usePathname } from "next/navigation"

type User = {
  id: string
  username: string
  role: string
  name: string
  cardId?: string
  department?: string
  status: string
}

type AuthContextType = {
  user: User | null
  isLoggedIn: boolean
  isAdmin: boolean
  login: (username: string, password: string) => Promise<boolean>
  logout: () => void
  hasPermission: (permission: string) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Definisi izin berdasarkan peran
const rolePermissions = {
  admin: [
    "view_dashboard",
    "view_access_logs",
    "view_motion_alerts",
    "view_statistics",
    "manage_users",
    "view_notifications",
    "manage_settings",
    "view_all_data",
  ],
  user: ["view_dashboard", "view_own_statistics", "view_door_status", "view_own_access_logs"],
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Cek status login dari localStorage saat komponen dimuat
    const checkLoginStatus = () => {
      const storedIsLoggedIn = localStorage.getItem("isLoggedIn")
      const storedUser = localStorage.getItem("user")

      if (storedIsLoggedIn === "true" && storedUser) {
        const parsedUser = JSON.parse(storedUser)
        setUser(parsedUser)
        setIsLoggedIn(true)
        setIsAdmin(parsedUser.role === "admin")
      }
      setIsLoading(false)
    }

    checkLoginStatus()
  }, [])

  useEffect(() => {
    // Redirect ke login jika tidak login dan bukan di halaman login
    if (!isLoading && !isLoggedIn && pathname !== "/login" && pathname !== "/register") {
      router.push("/login")
    }

    // Redirect ke dashboard jika sudah login dan di halaman login
    if (!isLoading && isLoggedIn && (pathname === "/login" || pathname === "/register")) {
      router.push("/")
    }

    // Cek akses ke halaman berdasarkan peran
    if (!isLoading && isLoggedIn && user) {
      // Halaman yang hanya bisa diakses admin
      const adminOnlyPages = ["/users", "/settings"]

      if (!isAdmin && adminOnlyPages.includes(pathname)) {
        router.push("/access-denied")
      }
    }
  }, [isLoggedIn, isLoading, pathname, router, user, isAdmin])

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Login failed")
      }

      const userData = data.user
      localStorage.setItem("isLoggedIn", "true")
      localStorage.setItem("user", JSON.stringify(userData))
      setUser(userData)
      setIsLoggedIn(true)
      setIsAdmin(userData.role === "admin")
      return true
    } catch (error) {
      console.error("Login error:", error)
      return false
    }
  }

  const logout = () => {
    localStorage.removeItem("isLoggedIn")
    localStorage.removeItem("user")
    setUser(null)
    setIsLoggedIn(false)
    setIsAdmin(false)
    router.push("/login")
  }

  const hasPermission = (permission: string): boolean => {
    if (!user) return false
    return rolePermissions[user.role as keyof typeof rolePermissions]?.includes(permission) || false
  }

  // Tampilkan loading spinner saat memeriksa status login
  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  return (
    <AuthContext.Provider value={{ user, isLoggedIn, isAdmin, login, logout, hasPermission }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
