"use client"

import { useAuth } from "@/components/auth-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DoorStatus } from "@/components/door-status"
import { Badge } from "@/components/ui/badge"
import { Clock } from "lucide-react"

export function UserDashboard() {
  const { user } = useAuth()

  // Data akses pengguna (simulasi)
  const userAccessLogs = [
    {
      id: "1",
      timestamp: "2025-05-01T08:30:00",
      location: "Pintu Utama",
      status: "success",
    },
    {
      id: "2",
      timestamp: "2025-05-01T12:30:00",
      status: "success",
      location: "Pintu Utama",
    },
    {
      id: "3",
      timestamp: "2025-05-01T17:30:00",
      status: "success",
      location: "Pintu Utama",
    },
  ]

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("id-ID", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date)
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="overflow-hidden">
          <CardHeader className="card-header-gradient">
            <CardTitle>Informasi Pengguna</CardTitle>
            <CardDescription>Detail informasi pengguna dan kartu RFID</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="rounded-lg border bg-gray-50 p-4 dark:bg-gray-800">
                <div className="grid gap-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Nama</span>
                    <span className="font-medium">{user?.name}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-500 dark:text-gray-400">ID Kartu</span>
                    <span className="font-medium">{user?.cardId}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-500 dark:text-gray-400">Status</span>
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">Aktif</Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden">
          <CardHeader className="card-header-gradient">
            <CardTitle>Status Pintu</CardTitle>
            <CardDescription>Status pintu real-time dan informasi terakhir</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <DoorStatus />
          </CardContent>
        </Card>
      </div>

      <Card className="overflow-hidden">
        <CardHeader className="card-header-gradient">
          <CardTitle>Riwayat Akses Pribadi</CardTitle>
          <CardDescription>Riwayat akses pintu menggunakan kartu RFID Anda</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="rounded-xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-950">
            <table className="w-full">
              <thead className="bg-gray-50 dark:bg-gray-900">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Waktu</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Lokasi</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-500 dark:text-gray-400">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200 dark:divide-gray-800">
                {userAccessLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-50 dark:hover:bg-gray-900">
                    <td className="px-4 py-3 text-sm">
                      <div className="flex items-center">
                        <Clock className="mr-2 h-4 w-4 text-gray-500 dark:text-gray-400" />
                        {formatDate(log.timestamp)}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm">{log.location}</td>
                    <td className="px-4 py-3 text-sm">
                      {log.status === "success" ? (
                        <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                          Berhasil
                        </Badge>
                      ) : (
                        <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">Gagal</Badge>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
